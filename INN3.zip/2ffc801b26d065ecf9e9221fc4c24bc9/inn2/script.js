$('[type="submit"]').click(function(event){
  event.preventDefault();
  send();
});

function send() {
  let data_tosend = '';
  for(let i=0; i<$('.inn-form input').length-1; i++){
    let elem = $('.inn-form input')[i];
    data_tosend += $(elem).attr('name') + '=' + $(elem).val() + '&';
  }
  $.ajax({
    method: 'POST',
    url:'obr.php',
    data: data_tosend,
    success: function(data) {
      alert(data);
    }
  });
}