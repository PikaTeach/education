<?
  $fam = htmlspecialchars(trim($_POST['fam']));
  $nam = htmlspecialchars(trim($_POST['nam']));
  $otch = htmlspecialchars(trim($_POST['otch']));
  $bdate = htmlspecialchars(trim($_POST['bdate']));
  $docno = htmlspecialchars(trim($_POST['docno']));
  if(empty($fam) or empty($nam) or empty($otch) or empty($bdate) or empty($docno)){
    exit('<script>alert("Не все поля заполнены")</script>');
  }
  //echo $fam.$nam.$otch.$bdate.$docno;
  $bdate = explode('-',$bdate);
  $bdate = $bdate[2].'.'.$bdate[1].'.'.$bdate[0];
  $docno = str_replace(" ","",$docno);
  $docno = substr($docno,0,2)." ".substr($docno,2,2)." ".substr($docno,4,6);
  
  $inn_url = "https://service.nalog.ru/inn-proc.do";
  $dolg_url = "https://nalogi.online/api/pv1/taxes/";
  $data_send = "c=innMy&captcha=&captchaToken=&fam=$fam&nam=$nam&otch=$otch&bdate=$bdate&bplace=&doctype=21&docno=$docno&docdt=";
  
  
  $inn = getCurl($inn_url,$data_send)["inn"];
  if(empty($inn)){
    exit('<script>alert("ИНН не найден")</script>');
  }
  $dolg_send = array("docs"=>array(array("type"=>"inn","value"=>"772151794049")));
  $dolg_send = json_encode($dolg_send);
  $dolgi = getCurl($dolg_url,$dolg_send)["penalties"]["penalty"];
  $dolgi_str = "";
  for($i=0; $i<count($dolgi); $i++){
    $dolgi_str =$dolgi_str."<p>".$dolgi[$i]["amount"].' руб. '.$dolgi[$i]["info"]["penaltyName"]."</p>";
  }
  exit($dolgi_str);
  
  function getCurl($url,$data){
    $curl=curl_init();
    curl_setopt($curl,CURLOPT_URL,$url);
    curl_setopt($curl,CURLOPT_POST,true);
    curl_setopt($curl,CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl,CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($curl);
    $result = json_decode($result,true);
    curl_close($curl);
    return $result;
  }
  
?>