  //Массив с названиями звуков:
  let arr_sound_id = ['Kick', 'Snare', 'Hihat', 'OpenHihat'];
  
   //Массив со сылками на звуки:
  let arr_sound = [];
  for(let i=0; i<arr_sound_id.length; i++){
    let temp = document.getElementById(arr_sound_id[i]);
    //temp.load();
    arr_sound.push(new Howl({src:[temp.src],html5:true,preload:true})); //завернул все звуки через новую библиотеку.
  }
  
  function butt (index){
    arr_sound[index].play();
  }
  
  
  
  //Массив:
    let arr = [];
  for(let i=0; i<16; i++){
    let arr2 = [];
    for(let j=0; j<4; j++){
      arr2.push(false);
    }
    arr.push(arr2);
  }
  //alert(JSON.stringify(arr));
  
  
  
  
  //Функция воспроизведения по кнопке "Play":
  let step = 0;
  let playing = false;
  function play_step(){
    if(playing){
      for(let i=0; i<arr_sound_id.length; i++){
        if(arr[step][i]){
          butt(i);
        }
      }
      if(step==15){
        step=0;
      } else{
        step=step+1;
      }
    }
  }
  
  function play(){
    playing=true;
  }
  setInterval(play_step,500);
  
  //Функция остановки по кнопке "Stop":
  function stop(){
    step = 0;
    playing = false;
  }
  
  //Функция паузы по кнопке "Pause":
  function pause(){
    playing = false;
  }
  
  //Формирование таблицы:
  let table = document.getElementById("table");
  for(h=0; h<4; h++){
    let tab = document.createElement("tr");
    table.append(tab);
    for(w=0; w<16; w++){
      //let tab2 = document.createElement("td");
      let butt2 = document.createElement('button');
      butt2.classList.add("tab_btn");
      let ryad = h;
      let colonka = w;
      butt2.onclick = function (but){
        if(arr[colonka][ryad]){
          arr[colonka][ryad]=false;
          butt2.style.backgroundColor ="LightBlue";
        } else {
          butt2.style.backgroundColor ="Thistle";
          arr[colonka][ryad] = true;
        }
        //alert(JSON.stringify(arr));
      };
      //tab.append(tab2);
      tab.append(butt2);
      butt2.style.backgroundColor ="LightBlue";
    }
  }
