<!doctype html>
<html lang="ru">

<head>
  <meta charset="UTF-8">
  <title>Пошаговый секвенсор</title>
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <!--Аудио-->
  <audio src="rock_kit/Kick.wav" id="Kick"></audio>
  <audio src="rock_kit/Snare.wav" id="Snare"></audio>
  <audio src="rock_kit/Hihat.wav" id="Hihat"></audio>
  <audio src="rock_kit/OpenHihat.wav" id="OpenHihat"></audio>
  <!--Визуалка-->

  <div>
    <!--Курсор-->
    <div id="cursor"></div>
    <!--Кнопки-->
    <div class="container">
      <div class="buttons">
        <div>
          <button class="button" onclick="butt(0)">Kick</button>
        </div>
        <div>
          <button class="button" onclick="butt(1)">Snare</button>
        </div>
        <div>
          <button class="button" onclick="butt(2)">Hihat</button>
        </div>
        <div>
          <button class="button" onclick="butt(3)">OpenHihat</button>
        </div>
      </div>
      <!--Таблица-->
      <div>
        <table id="table" border="1"></table>
      </div>
    </div>
  </div>
  <!--Кнопки воспроизведения-->
  <div class="control">
    <div>
      <button class="play" onclick="play()">
        <i class="fa fa-play" aria-hidden="true"></i>
      </button>
    </div>
    <div>
      <button class="pause" onclick="pause()">
        <i class="fa fa-pause" aria-hidden="true"></i>
      </button>
    </div>
    <div>
      <button class="stop" onclick="stop()">
        <i class="fa fa-stop" aria-hidden="true"></i>
      </button>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/howler/2.1.2/howler.min.js"></script>
  <!--Новая библиотека-->
  <script src="script.js"></script>
</body>

</html>
