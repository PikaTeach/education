<!doctype html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Пошаговый секвенсор</title>
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
</head>
<style>
  .container {
    display: flex;
  }
  .buttons {
    flex-direction: column;
  }
  .button {
    margin: 3px;
    width: 80px;
    height: 24px;
  }
  .control {
    padding-top: 10px;
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
  }
  .play {
    margin-left: 3px;
    width: 80px;
    height: 50px;
  }
  .pause {
    margin-left: 3px;
    width: 80px;
    height: 50px;
  }
  .stop {
    margin-left: 3px;
    width: 80px;
    height: 50px;
  }
  .tab_btn {
    margin: 1px;
    background-color:LightBlue;
    width: 40px;
    height: 25px;
  }
</style>
<body>
  <!--Аудио-->
  <audio src="aud/Kick.wav" id="Kick"></audio>
  <audio src="aud/Snare.wav" id="Snare"></audio>
  <audio src="aud/Hihat.wav" id="Hihat"></audio>
  <audio src="aud/OpenHihat.wav" id="OpenHihat"></audio>
  <!--Визуалка-->
  <div class="container">
    <!--Кнопки-->
    <div class="buttons">
      <div>
        <button class="button"  onclick="butt(0)" >Kick</button>
      </div>
      <div>
        <button class="button" onclick="butt(1)" >Snare</button>
      </div>
      <div>
        <button class="button" onclick="butt(2)" >Hihat</button>
      </div>
      <div>
        <button class="button" onclick="butt(3)" >OpenHihat</button>
      </div>
    </div>
    <!--Таблица-->
    <div>
      <table id="table" border="1"></table>
    </div>
  </div>
  <!--Кнопки воспроизведения-->
  <div class="control">
    <div>
      <button class="play" onclick="play()" >
        <i class="fa fa-play" aria-hidden="true"></i>
      </button>
    </div>
    <div>
      <button class="pause" onclick="pause()" >
        <i class="fa fa-pause" aria-hidden="true"></i>
      </button>
    </div>
    <div>
      <button class="stop" onclick="stop()" >
        <i class="fa fa-stop" aria-hidden="true"></i>
      </button>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/howler/2.1.2/howler.min.js"></script> <!--Новая библиотека-->
  <script src="script.js"></script>
</body>
</html>