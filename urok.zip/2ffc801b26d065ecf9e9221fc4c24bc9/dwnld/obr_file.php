<?php
  $fileType = $_FILES['userFile']['type'];
  if($fileType == 'image/jpeg' or $fileType == 'image/png' or $fileType == 'image/bmp'){
    $dir = "archive/";
    $file = basename($_FILES['userFile']['name']);
    $file = microtime().'-'.basename($file);
    $pathFile = $dir.$file;
    move_uploaded_file($_FILES['userFile']['tmp_name'],$pathFile);
    exit('Completed!');
  }
  else
    exit('ERROR!!!');
  
?>