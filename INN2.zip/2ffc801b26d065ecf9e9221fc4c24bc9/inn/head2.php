<?
$title="УЗНАТЬ ИНН";
include 'head.php';
?>
    
    <div class="container my-5">
      <h1 class="text-center">ИНН</h1>
      <div class="row justify-content-center">
        <div class="col-md-5">
          <form class="inn-form">
            <div class="form-group">
              <div class="input-group mb-2">
                <div class="input-group-prepend">

                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="input-group mb-2">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa fa-id-card-o" aria-hidden="true"></i>
                  </div>
                </div>
                <input name="fam" required placeholder="Фамилия" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <div class="input-group mb-2">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa fa-id-card-o" aria-hidden="true"></i>
                  </div>
                </div>
                <input name="nam" required placeholder="Имя" class="form-control" type="text">
              </div>
            </div>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa fa-id-card-o" aria-hidden="true"></i>
                  </div>
                </div>
                <input name="otch" required placeholder="Отчество" class="form-control" type="text">
              </div>
              <div class="form-group">
              <div class="input-group mb-2">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa fa-id-card-o" aria-hidden="true"></i>
                  </div>
                </div>
                <input name="docno" required placeholder="Номер паспорта" class="form-control" type="text">
              </div>
              </div>
              <div class="form-group">
                <div class="input-group mb-2">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fa fa-calendar" aria-hidden="true"></i>
                    </div>
                  </div>
                  <input name="bdate" id="bithday" type="date" class="form-control" placeholder="Дата рождения">
                </div>
              </div>
                <input class="btn btn-primary form-control" type="submit" value="Узнать ИНН">
              </div>
          </form>
        </div>
      </div>
    </div>
    <!-- Optional JavaScript -->
    <script src="script.js"></script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
       <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>